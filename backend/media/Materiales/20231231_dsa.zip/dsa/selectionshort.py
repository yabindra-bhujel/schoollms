import random
import time

# Generate a list of 100 random numbers between 1 and 1000
my_list = [random.randint(1, 10000000) for _ in range(100000)]

# Print the unsorted list

# Selection Sort
def selection_sort(arr):
    n = len(arr)

    for i in range(n-1):
        min_index = i
        for j in range(i+1, n):
            if arr[j] < arr[min_index]:
                min_index = j

        arr[i], arr[min_index] = arr[min_index], arr[i]

# Measure the time taken by the selection sort
start_time = time.time()
selection_sort(my_list)
end_time = time.time()

# Print the sorted list
print("Sorted array:", my_list)

# Print the time taken
print(f"Time taken: {end_time - start_time} seconds")
