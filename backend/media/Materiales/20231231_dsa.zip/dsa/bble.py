def bubble_sort(arr):
    n = len(arr)
    for i in range(n):
        for j in range(0, n-i-1):
            if arr[j] > arr[j+1]:
                arr[j], arr[j+1] = arr[j+1], arr[j]


mylist = [1,3,4,56,6,7,7,8,834,99,100]
bubble_sort(mylist)
print("Sorted array is:", mylist)




def liner_search(arr, target):
    for i in range(len(arr)):
        if arr[i] == target:
            return i
    return -1

mylist = [1,3,4,56,6,7,7,8,834,99,100]
target = 7
result = liner_search(mylist, target)
print(result)