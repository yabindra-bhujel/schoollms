

# name = "Yabindra Bhujel"

# first_name = name[:8]
# last_name = name[9:]
# print(first_name)
# print(last_name)

# reversed_name = name[::-1]
# print(reversed_name)


wbsitename = "http://www.google.com"
slicc = slice(11, -4)
print(wbsitename[slicc])

hostname = wbsitename[11:-4]
print(hostname)