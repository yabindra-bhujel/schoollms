def maximize_team_happiness(n, seats):
    def is_valid(seat, team_size):
        return seat >= team_size

    def calculate_happiness(teams, reservations):
        total_happiness = 0
        for i, team in enumerate(teams):
            total_happiness += sum(reservations[i][j] for j in team)
        return total_happiness

    def backtrack(current_team, current_happiness, current_reservations):
        nonlocal max_happiness

        if current_team == n:
            max_happiness = max(max_happiness, current_happiness)
            return

        for i in range(len(seats[0])):
            if not visited[i]:
                valid = True
                for j in current_team:
                    if not is_valid(seats[j][i], team_sizes[j]):
                        valid = False
                        break

                if valid:
                    visited[i] = True
                    for j in current_team:
                        current_reservations[j][i] += team_sizes[j]

                    backtrack(
                        current_team + [i],
                        current_happiness + calculate_happiness(
                            current_team, current_reservations
                        ),
                        current_reservations,
                    )

                    visited[i] = False
                    for j in current_team:
                        current_reservations[j][i] -= team_sizes[j]

    max_happiness = 0
    visited = [False] * len(seats[0])
    team_sizes = [len(team) for team in seats]
    backtrack([], 0, [[0] * len(seats[0]) for _ in range(n)])

    return max_happiness


# Example usage
n = 4
seats = [
    [3, 0, 1],
    [1, 3, 3],
    [9, 3, 2],
    [2, 0, 2],
]
result = maximize_team_happiness(n, seats)
print(result)
