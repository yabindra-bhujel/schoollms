def fib(n):
    fib_sequence = [0,1]
    if n == 0 & n == 1:
        return n
    
    while len(fib_sequence) < n:
        fib_sequence.append(fib_sequence[-1] + fib_sequence[-2])

        return fib_sequence[:n]
    

result = fib(10)
print(result)

    

    
