class Node:
    def __init__(self, value):
        self.value = value
        self.next = None



class Linklist:
    def __init__(self):
        self.head = None

        
