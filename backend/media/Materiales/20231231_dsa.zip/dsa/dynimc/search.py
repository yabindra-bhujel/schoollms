def lineraSearch(arr, target):
    for i in range(len(arr)):
        if arr[i] == target:
            return i
        
    return -1


arr = [1,23,254,657,99]
target = 254

print(lineraSearch(arr, target))