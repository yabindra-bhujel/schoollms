from datetime import datetime, timedelta

def get_dates_of_month(event_days):
    # Get the current date
    today = datetime.now()

    # Calculate the first day of the current month
    first_day_of_month = today.replace(day=1)

    # Calculate the last day of the current month
    last_day_of_month = (first_day_of_month + timedelta(days=32)).replace(day=1) - timedelta(days=1)

    # Generate a list of dates for the entire month
    all_dates = [first_day_of_month + timedelta(days=i) for i in range((last_day_of_month - first_day_of_month).days + 1)]

    # Print only the dates that correspond to the specified event days
    for date in all_dates:
        if date.strftime('%A') in event_days:
            print(date.strftime('%Y-%m-%d'))

# Example: Get and print dates for specific event days (Monday, Sunday, Friday)
event_days = ["Monday"]
get_dates_of_month(event_days)
