# from collections import deque

# stack = deque()

# stack.append(1)
# stack.append(2)
# stack.append(3)
# stack.append(4)
# stack.append(5)
# stack.appendleft(10)


# stack.pop()
# list(stack)
# # search
# if 5 in stack:
#     print("found")



# stack.extend([11, 12, 13])
# stack.extendleft([20, 21, 22])


# deque(reversed(stack))

# print(stack)
# stack.clear()
# stack.pop()
# print(stack)



# LIFO - Last In First Out


# use case
# undo and redo
# browser back and forward



class Stack:
    def __init__(self):
        self.item = []

    def is_empty(self):
        return len(self.item) == 0
    
    def push(self, items):
        self.item.append(items)

    def pop(self):
        if not self.is_empty():
            return self.item.pop()
        else:
            raise IndexError("pop from an empty stack")
    def peek(self):
        if not self.is_empty:
            return self.item[-1]
        else:
            raise IndexError("peek from an empty stack")
        

    def size(self):
        return len(self.item)

    

stack = Stack()

stack.push(1)
stack.push(2)
stack.push(3)
stack.push(4)
stack.peek()

print(stack.peek)

