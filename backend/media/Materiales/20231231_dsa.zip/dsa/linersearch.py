def linersearc(arr: list, target: int) -> int:
    for i in range(len(arr)):
        if arr[i] == target:
            return i
    return - 1
    

number = [1,20,22, 40, 50]
target = 500
print(linersearc(number, target))



# Create a function that performs linear search to find a target element in a list and replaces it with a new value. Return the modified list.


# def newlist(arr: list, target: int, newvalue: int) -> int:
#     for i in range(len(arr)):
#         if arr[i] == target:
#             arr[i] =newvalue
#             return i
#     return -i


# number = [1,20,22, 40, 50]
# target = 50
# newvalue = 100
# print(newlist(number, target, newvalue))
# print(number)


# def diffrentdataType(arr, target):
#     for i in range(len(arr)):
#         if arr[i] == target:
#             return True
#     return -1
# print(diffrentdataType([1,"a",3], 5))


# def reverse_sublist_until_target(arr: list, target: int) ->list:
#     for i in range(len(arr)):
#         if arr[i] == target:
#             arr[:+1] = arr[:i+1][::-1]
#             return arr
    
#     return -1

# my_list = [1, 2, 3, 4, 5, 6]
# target_element = 4
# result = reverse_sublist_until_target(my_list, target_element)
# print(result)



# Create a function that performs linear search to count the number of occurrences of a target element in a list.


# def count_occurrence(arr: list, target: int)->int:
#     counter = 0
#     for i in range(len(arr)):
#         if arr[i] == target:
#             counter += 1
#             return i
        
#     return -1


# my_list = [1, 2, 3, 4, 5, 6]
# target_element = 4

# print(count_occurrence(my_list, target_element))



# Extend the linear search function to remove all occurrences of a target element from the list and return the modified list without duplicates.





# def remove(arr:list)->list:
#     newar = []
#     for i in range(len(arr)):
#         if arr[i] not in newar:
#             newar.append(arr[i])
#     return newar


# mylist = [1, 3, 4, 5,6, 4, 5, 10, 10, 10, ]
# target = 10
# print(remove(mylist))



# def repalceName(arr: list, name: str, newname: str) ->list:
#     newnamearr = []
#     for i in range(len(arr)):
#         if arr[i] == name:
#             arr[i] = newname
#             newnamearr.append(newname)
#     return newnamearr
        

# listm = [ "yabindra", "bhujel"]
# print(repalceName(listm,"yabindra","Sabitri"))