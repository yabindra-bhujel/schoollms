# def binarySearch(arr: list, target:int, low:int, heigh:int)->int:
#     while low <= heigh:
#         mid = (low + heigh) // 2
#         if arr[mid] == target:
#             return mid
#         elif arr[mid] < target:
#             low = mid + 1
#         else:
#             heigh = mid - 1
#     return -1

# my_list = [1, 2, 3, 4, 5, 6]
# target_element = 4
# result = binarySearch(my_list, target_element, 0, len(my_list)-1)
# print(result)


import random



def bubble_sort(arr):
    n = len(arr)
    for i in range(n):
        for j in range(0, n-i-1):
            if arr[j] > arr[j+1]:
                arr[j], arr[j+1] = arr[j+1], arr[j]



def binarySearch(arr, target, low, heigh):
    while low<= heigh:
        middle_point = (low + heigh) //2 
        print("middle", middle_point)

        if arr[middle_point] == target:
            return middle_point
        elif arr[middle_point] < target:
            low = middle_point + 1
            print("low",low)
        else:
            heigh = middle_point -1
            print("heigh", heigh)

    return -1






# my_list =  [7, 14, 19, 20, 36, 39, 63, 64, 67, 77, 89, 103, 105, 131, 138, 139, 141, 179, 210, 232, 256, 266, 272, 273, 286, 287, 299, 335, 351, 357, 377, 388, 413, 423, 426, 438, 439, 454, 467, 470, 470, 471, 486, 493, 502, 503, 565, 572, 580, 585, 594, 597, 602, 613, 617, 622, 626, 639, 641, 642, 644, 645, 674, 681, 688, 695, 700, 706, 712, 719, 747, 747, 748, 748, 751, 784, 799, 821, 829, 830, 831, 843, 850, 858, 868, 879, 893, 894, 902, 907, 909, 910, 915, 915, 924, 926, 929, 945, 981, 997]

# target = 7
# result = binarySearch(my_list, target, 0, len(my_list)-1)
# print(result)



def binersearc(arr, target):
    low, heigh = 0, len(arr)-1

    while low <= heigh:
        middel_point = (low + heigh) // 2
        if arr[middel_point] == target:
            return middel_point
        elif arr[middel_point] < target:
            low = middel_point +1
        else:
            heigh = middel_point -1

    return -1

        


nums = [-1, 0, 3, 5, 9, 12]
target = 9
print(binersearc(nums, target))


