def bubble_sort(arr):
    n = len(arr)

    # Traverse through all elements in the list
    for i in range(n):

        # Last i elements are already sorted, so we don't need to check them
        for j in range(0, n-i-1):

            # Swap if the element found is greater than the next element
            if arr[j] > arr[j+1]:
                arr[j], arr[j+1] = arr[j+1], arr[j]

# Example usage:
my_list = [64, 34, 25, 12, 22, 11, 90]
bubble_sort(my_list)







def bubble(arr):
    n = len(arr)
    
    for i in range(n):
        for j in range(0, n-i-1):
            if arr[j] > arr[j+1]:
                arr[j], arr[j+1] = arr[j+1], arr[j]


# Example usage:
my_list = [64, 34, 25, 12, 22, 11, 9]
bubble(my_list)



def bbb(arr):
    n = len(arr)
    for i in range(n):
        for j in range(0, n-i-1):
            if arr[j] > arr[j+1]:
                arr[j], arr[j+1] = arr[j +1] , arr[j]





# Example usage:
my_list = [64, 34, 25, 12, 22, 11, 9]
bbb(my_list)
print("Sorted array:", my_list)



def db(arr):
    n = len(arr)
    for i in range(n):
        for j in range(0, n-i-1):
            if arr[j] < arr[j+1]:
                arr[j], arr[j+1] = arr[j+1] , arr[j]



my_list = [64, 34, 25, 55, 22, 11, 9, 100, 500]
db(my_list)
print("Sorted array:", my_list)


def bble_sort(arr:list)->None:
    n = len(arr)
    for i in range(n):
        for j in range(0, n-i-1):
            if arr[j] > arr[j+1]:
                arr[j], arr[j+1] = arr[j+1], arr[j]

my_list = [64, 34, 25, 12, 22, 11,
           9, 8, 7, 6, 5, 4, 3, 2, 1]
bble_sort(my_list)
print("Sorted array:", my_list)




def bbll(arr):
    n = len(arr)
    for i in range(n):
        for j in range(0, n-i-1):
            if arr[j] > arr[j+1]:
                arr[j], arr[j+1] = arr[j+1], arr[j]
                
